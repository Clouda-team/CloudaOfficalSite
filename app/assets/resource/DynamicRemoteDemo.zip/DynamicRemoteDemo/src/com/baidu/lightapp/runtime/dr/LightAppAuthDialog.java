package com.baidu.lightapp.runtime.dr;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;

import com.baidu.sapi2.SapiWebView;
import com.baidu.sapi2.SapiWebView.OnFinishCallback;

/**
 * @author zhangchi09
 * 
 */
public class LightAppAuthDialog extends Dialog {
	private static final String TAG = "LightAppAuthDialog";
	
	/**
	 * 氓艩聽猫陆陆忙沤藛忙聺茠茅隆碌茅聺垄莽拧鈥濿ebView忙沤搂盲禄露
	 */
	private SapiWebView mWebView;
	
	/**
	 * 忙沤藛忙聺茠氓鈥号久捌抣istener
	 */
	private class FinishCallback implements OnFinishCallback {
		private final OnFinishCallback mCallBack;

		FinishCallback(OnFinishCallback callBack) {
			mCallBack = callBack;
		}

		@Override
		public void onFinish() {
			mCallBack.onFinish();
//			mWebView.destroy();
		}

	}

	private FinishCallback mFinishCallback;
	
	public LightAppAuthDialog(Context context, OnFinishCallback finishcallback) {
		super(context, android.R.style.Theme_Light_NoTitleBar);
		mFinishCallback = new FinishCallback(finishcallback);
		setupWebView(context);
	}
	
    private void setupWebView(Context context) {
		mWebView = new SapiWebView(context);
		mWebView.setVerticalScrollBarEnabled(true);
		mWebView.resumeTimers();
		Log.i(TAG, "resume webview Timer");
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.setOnFinishCallback(mFinishCallback);
		LayoutParams viewParam =
				new ViewGroup.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT,
						ViewGroup.LayoutParams.FILL_PARENT);
		addContentView(mWebView,viewParam);
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mWebView.loadLogin();
	}
	
	@Override
	public void onBackPressed() {
	    mWebView.setFocusable(false);
	    Log.d(TAG,"onbackPressed");
	    mWebView.finish();
//	    mWebView.destroy();
	}
	
	@Override
	protected void onStop() {
	    super.onStop();
	    if(null != mWebView){
	        //mWebView.pauseTimers();
	        Log.i(TAG, "pause webview Timer");
	    }
	}
	
	public void releaseMemory() {
		if (mWebView != null) {
			Log.i(TAG, "release webview memory");
			mWebView.destroy();
		}
	}
}