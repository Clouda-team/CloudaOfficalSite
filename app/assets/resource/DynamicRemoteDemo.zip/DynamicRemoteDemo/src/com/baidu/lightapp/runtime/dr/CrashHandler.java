package com.baidu.lightapp.runtime.dr;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Date;

import android.os.Debug;
import android.os.Environment;
import android.util.Log;

public class CrashHandler implements UncaughtExceptionHandler {

	public static final String TAG = "CrashHandler";
	private Thread.UncaughtExceptionHandler mDefaultHandler;
	private static final String OOM = "java.lang.OutOfMemoryError";

	private static CrashHandler sCrashHandler;

	private CrashHandler() {
	}

	public synchronized static CrashHandler getInstance() {
		if (sCrashHandler == null) {
			sCrashHandler = new CrashHandler();
		}
		return sCrashHandler;
	}

	public void init() {
		mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
		Thread.setDefaultUncaughtExceptionHandler(this);
	}

	public static boolean isOOM(Throwable throwable) {
		Log.d(TAG, "getName:" + throwable.getClass().getName());
		if (OOM.equals(throwable.getClass().getName())) {
			return true;
		} else {
			Throwable cause = throwable.getCause();
			if (cause != null && OOM.equals(cause.getClass().getName())) {
				// return isOOM(cause);
				return true;
			} else {
				return false;
			}
		}
	}

	@Override
	public void uncaughtException(Thread thread, Throwable throwable) {
		// if(isOOM(throwable)){
		try {
			// System.gc();
			String HPROF_FILE_PATH = Environment.getExternalStorageDirectory()
					.getPath()
					+ "/"
					+ throwable.getClass().getName()
					+ ".hprof." + new Date().getTime();
			Debug.dumpHprofData(HPROF_FILE_PATH);
		} catch (Exception e) {
			Log.e(TAG, "couldn't dump hprof", e);
		}
		// }

		if (mDefaultHandler != null) {
			mDefaultHandler.uncaughtException(thread, throwable);
		} else {
			android.os.Process.killProcess(android.os.Process.myPid());
			System.exit(1);
		}
	}
}
