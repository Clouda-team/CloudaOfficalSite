package com.baidu.lightapp.runtime.dr;

import android.content.Context;
import android.os.Handler;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;

import com.baidu.sapi2.SapiAccount;
import com.baidu.sapi2.SapiAccountManager;
import com.baidu.sapi2.SapiConfiguration;
import com.baidu.sapi2.SapiWebView.OnFinishCallback;
import com.baidu.sapi2.utils.enums.BindType;
import com.baidu.sapi2.utils.enums.Domain;
import com.baidu.sapi2.utils.enums.LoginShareStrategy;
import com.baidu.sumeru.lightapp.channel.IRuntimeChannel;

public class LoginImpl implements IRuntimeChannel {
    private Context mContext;
    private LightAppAuthDialog mLightAppAuthDialog;
    private AccountInfo mAccountInfo;
    public void setLoginListener(LoginListener listener) {

    }

    public LoginListener getLoginListener() {
        return null;
    }

    public void setContext(Context context) {
        mContext = context;
        if (context == null) {
            releaseLoginDialog();
        }
    }

    public boolean isLogin(Handler handler) {
        try {
            SapiAccountManager.getInstance().getSapiConfiguration();
        } catch (IllegalStateException ex) {
            init();
        }

        return SapiAccountManager.getInstance().isLogin();
    }
    
    public void login(LoginListener loginStatusListener) {
        try {
            SapiAccountManager.getInstance().getSapiConfiguration();
        } catch (IllegalStateException ex) {
            init();
        }
        if (!SapiAccountManager.getInstance().isLogin()) {
            releaseLoginDialog();
            mLightAppAuthDialog = new LightAppAuthDialog(mContext,
                    new LoginFinishedCallback(loginStatusListener));
            mLightAppAuthDialog.show();
        }
    }

    public void logout() {
        try {
            SapiAccountManager.getInstance().getSapiConfiguration();
        } catch (IllegalStateException ex) {
            init();
        }
        // logout
        SapiAccountManager.getInstance().logout();

        if (mContext == null) {
            return;
        }

        try {
            final String COOKIE_URL = "http://www.baidu.com";
            final String bdussCookie = "BDUSS=;domain=baidu.com;path=/";

            CookieSyncManager.createInstance(mContext);
            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setAcceptCookie(true);
            cookieManager.setCookie(COOKIE_URL, bdussCookie);
            CookieSyncManager.getInstance().sync();
        } catch (Throwable e) {
        }
    }

    public AccountInfo getAccountInfo() {
        if (isLogin(null)) {
            SapiAccount sapiAccount = SapiAccountManager.getInstance()
                    .getSession();
            mAccountInfo = new AccountInfo();

            mAccountInfo.app = sapiAccount.app;
            mAccountInfo.bduss = sapiAccount.bduss;
            mAccountInfo.displayName = sapiAccount.displayname;
            mAccountInfo.email = sapiAccount.email;
            mAccountInfo.extra = sapiAccount.extra;
            mAccountInfo.phone = sapiAccount.phone;
            mAccountInfo.ptoken = sapiAccount.ptoken;
            mAccountInfo.stoken = sapiAccount.stoken;
            mAccountInfo.uid = sapiAccount.uid;
            mAccountInfo.userName = sapiAccount.username;
            return mAccountInfo;
        }
        return null;
    }

    private class LoginFinishedCallback implements OnFinishCallback {
        LoginListener mLoginStatusListener;

        public LoginFinishedCallback(LoginListener l) {
            mLoginStatusListener = l;
        }

        @Override
        public void onFinish() {
            if (mLightAppAuthDialog != null && mLightAppAuthDialog.isShowing()) {
                mLightAppAuthDialog.dismiss();
//              mLightAppAuthDialog = null;
            }
            if (SapiAccountManager.getInstance().isLogin()) {
                if (null != mLoginStatusListener) {
                    SapiAccount sapiAccount = SapiAccountManager.getInstance()
                            .getSession();
                    mAccountInfo = new AccountInfo();

                    mAccountInfo.app = sapiAccount.app;
                    mAccountInfo.bduss = sapiAccount.bduss;
                    mAccountInfo.displayName = sapiAccount.displayname;
                    mAccountInfo.email = sapiAccount.email;
                    mAccountInfo.extra = sapiAccount.extra;
                    mAccountInfo.phone = sapiAccount.phone;
                    mAccountInfo.ptoken = sapiAccount.ptoken;
                    mAccountInfo.stoken = sapiAccount.stoken;
                    mAccountInfo.uid = sapiAccount.uid;
                    mAccountInfo.userName = sapiAccount.username;

                    mLoginStatusListener.onSuccess(mAccountInfo);
                }
            } else {
                if (mLoginStatusListener != null) {
                    mLoginStatusListener.onFail(
                            LightAppLoginErrorInfo.ERROR_CODE_CANCELED,
                            LightAppLoginErrorInfo.ERROR_MSG_CANCELED);
                }
            }
        }

    }

    public void init() {
        SapiConfiguration config = new SapiConfiguration.Builder(
                mContext.getApplicationContext())
                // .setProductLineInfo("esfb", "2",
                // "e56b4eb0473d219c5317afb7ccf66e8f")
                .setProductLineInfo(SSOConstants.DEFAULT_PASS_TPL,
                        SSOConstants.DEFAULT_PASS_APPID,
                        SSOConstants.DEFAULT_PASS_SAPI_KEY)
                .setDeviceLoginSignKey("12345")
//              .enableYi(false)
                // .fastLoginSupport(FastLoginFeature.SINA_WEIBO_SSO,
                // FastLoginFeature.TX_QQ_WEBVIEW,
                // FastLoginFeature.RENREN_WEBVIEW,
                // FastLoginFeature.TX_WEIBO_WEBVIEW)
                .setRuntimeEnvironment(Domain.DOMAIN_ONLINE)
                .setSocialBindType(BindType.IMPLICIT)
                .initialShareStrategy(LoginShareStrategy.CHOICE).debug(true)
                .build();
        SapiAccountManager.getInstance().init(config);
    }

    private class LightAppLoginErrorInfo {
        public static final int ERROR_CODE_CANCELED = 1;
        public static final String ERROR_MSG_CANCELED = "login canceled";
    }

    private final class SSOConstants {
        static final String DEFAULT_PASS_APPID = "1";
        static final String DEFAULT_PASS_TPL = "lightapp";
        static final String DEFAULT_PASS_SAPI_KEY = "868afbf73668be284729913836b261d1";
    }

    public void releaseLoginDialog() {
        if (mLightAppAuthDialog != null) {
            mLightAppAuthDialog.releaseMemory();
            mLightAppAuthDialog = null;
        }
    }
}