package com.baidu.lightapp.runtime.dr;

import java.io.File;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.sumeru.lightapp.sdk.LightAppRuntime;
import com.baidu.sumeru.lightapp.sdk.LightAppRuntime.LoadListener;

public class DrDemoActivity extends Activity {

    private static final String TAG = "DrDemo";
    private boolean mIsStartLightApp = false;
    private String mUrl;
    private TextView mProgressView;

    MyHandler mHandler = new MyHandler();

    class MyHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
			case 0:
                doNewSchemeStartWithSilentUpdateLogic();
				break;
			case 1:
				onLightAppStarted();
			default:
				break;
			}
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        Log.i(TAG, "begin to set content view");
        setContentView(R.layout.drdemo_main_activity);
        mProgressView = (TextView) findViewById(R.id.progress);
        mHandler.sendEmptyMessageDelayed(0, 1000);
    }

    protected void onLightAppStarted() {
        this.finish();
    }

    private LoadListener mLoadListener = new LoadListener() {
        @Override
        public void onProgress(int progress) {
            Log.d(TAG, "dynamicDemo onProgress()  progress= " + progress);

            mProgressView.setText(String.valueOf(progress));
        }

        @Override
        public void onFinished(boolean success, String errorMessage) {
            Log.d(TAG, "NewScheme dynamicDemo onFinished()  success= "
                    + success + " ,errorMessage= " + errorMessage);

            if (success) {
                showLightApp(true);
            } else {
                if (LightAppRuntime.isRuntimeAvailable(getApplicationContext())) {
                    showLightApp(true);
                } else {
                    onLightAppStarted();
                    Toast.makeText(DrDemoActivity.this, errorMessage,
                            Toast.LENGTH_LONG).show();
                }
            }
        }
    };

    protected synchronized void startLightApp(final String url) {
        if (null == url) {
            onLightAppStarted();
            return;
        }
        mUrl = url;

        if (mIsStartLightApp) {
            return;
        }
        mIsStartLightApp = true;

        synchronized (DrDemoActivity.this) {
            if (!DrDemoActivity.this.isFinishing()) {
                LightAppRuntime.launchLightApp(DrDemoActivity.this, mUrl);
            }
            mIsStartLightApp = false;
            onLightAppStarted();
        }
    }

    private void doNewSchemeStartWithSilentUpdateLogic() {
        LightAppRuntime.initialize(getApplicationContext(), 
                mLoadListener);
    }

//    private void doNewSchemeUpdateLogic() {
//         LightAppRuntime.update(mLoadListener);
//    }

    private String getUrlForPlgDevelop() {
        if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED) == false) {
            Log.d(TAG, "Not found sdcard!");
            return "";
        }
        
        File sdcardDir = Environment.getExternalStorageDirectory();
        if(sdcardDir.exists() == false) {
            Log.d(TAG, "Not found sdcard!");
        	return "";
        }
        
        File htmlFile = new File(sdcardDir.getAbsoluteFile() + "/" + "pluginDemo.html");
        if(htmlFile.exists() == false) {
            Log.d(TAG, "Not found test html!");
            return "";
        }
        
        return "file://" + htmlFile.getAbsolutePath();
    }
    
    private void showLightApp(boolean isNewScheme) {
        Log.i(TAG, "begin to start light app");
        String url = getUrlForPlgDevelop();
        if(TextUtils.isEmpty(url)){
        	Log.d(TAG, "enter Runtime Demo branch...");
            LaunchLightAppThread launchThread = new LaunchLightAppThread(
                    isNewScheme, "http://m.baidu.com/lightapp");
            launchThread.start();
        }
        else{
        	Log.d(TAG, "enter Plugin Demo branch...");
            LaunchLightAppThread launchThread = new LaunchLightAppThread(
                    isNewScheme, url);
            launchThread.start();
        }


    }

    private class LaunchLightAppThread extends Thread {
        private String url = "";

        public LaunchLightAppThread(boolean aIsNewScheme, String aUrl) {
            url = aUrl;
        }

        @Override
        public void run() {
            super.run();
            if (!DrDemoActivity.this.isFinishing()) {
                LightAppRuntime.launchLightApp(getApplicationContext(), url);
                mHandler.sendEmptyMessageDelayed(1, 5000);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //System.exit(0);
        // recycleBgRes();
    }

//    private void recycleBgRes() {
//        View view = ((ViewGroup) findViewById(android.R.id.content))
//                .getChildAt(0);
//        BitmapDrawable bitmap = (BitmapDrawable) view.getBackground();
//        Log.d(TAG, "dynamicDemo view :" + view + " ,drawable :" + bitmap);
//        if (null != bitmap && !bitmap.getBitmap().isRecycled()) {
//            bitmap.getBitmap().recycle();
//        }
//        mHandler = null;
//        bitmap = null;
//        view.setBackground(null);
//        view = null;
//        System.gc();
//    }
}
