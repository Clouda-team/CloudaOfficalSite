package com.baidu.lightapp.runtime.dr;

import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;

import android.app.Application;

import com.baidu.sumeru.lightapp.channel.IRuntimeChannel;
import com.baidu.sumeru.lightapp.channel.LoginManager;
import com.baidu.sumeru.lightapp.sdk.RuntimeTest;

@ReportsCrashes(
        formKey = "",
        formUri = "http://10.212.183.60:8984/acra-runtime/_design/acra-storage/_update/report",
        reportType = org.acra.sender.HttpSender.Type.JSON,
        httpMethod = org.acra.sender.HttpSender.Method.PUT,
        formUriBasicAuthLogin="linrongwen",
        formUriBasicAuthPassword="123456",
        mode = ReportingInteractionMode.SILENT
        )

public class DemoApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        if (RuntimeTest.ENABLE) {
            ACRA.init(this);
            // CrashHandler.getInstance().init();
        }

        IRuntimeChannel login = new LoginImpl();
        LoginManager.getInstance().setLoginImpl(login);
    }
}
