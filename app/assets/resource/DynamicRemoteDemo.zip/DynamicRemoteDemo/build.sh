   #!/bin/bash

export PATH=`pwd`/test/build-tools/17.0.0/:$PATH;

set -e

TOP=`pwd`;
OUT=$TOP/out;
OUT_PLUGINS=$OUT/plugins;
OUT_INTERMEDIATES=$OUT/intermediates;
OUT_INSTRUMENT=$OUT/instrument;
PUBLIC=$TOP/public;
PRODUCT=$OUT/product;
NETDISK=$PRODUCT/netdisk;

LIBCORE_KEY=$OUT_INTERMEDIATES/libcore.key
RUNTIME_KEY=$OUT_INTERMEDIATES/runtime.key

FRONTIA_JAR=$PUBLIC/Baidu-Frontia-Base-Debug.jar;


DEVICE_PLG=$OUT_PLUGINS/Device/device.plg
DEVICE_KEY=$OUT_PLUGINS/Device/device.key
MAP_PLG=$OUT_PLUGINS/Map/map.plg
MAP_KEY=$OUT_PLUGINS/Map/map.key
BARCODE_PLG=$OUT_PLUGINS/Barcode/barcode.plg
BARCODE_KEY=$OUT_PLUGINS/Barcode/barcode.key



    echo "build demo dynamic...";
    cd demo/DynamicRemoteDemo;
    if [ -z $INCREMENTAL ]
    then
        ant rt-init;
    fi
    cp $OUT/runtime-dynamic-remote.jar libs
    if [ -z $INCREMENTAL ];then ant clean;fi
    ant build -DBUILD_VERSION=$VERSION;
    java -jar ../../test/emma_coverage/signapk.jar  ../../test/emma_coverage/testkey.x509.pem ../../test/emma_coverage/testkey.pk8 bin/runtime-demo.apk bin/runtime-demo-signed.apk
    cp bin/runtime-demo-signed.apk $OUT/runtime-demo-dynamic.apk
    back_to_top
